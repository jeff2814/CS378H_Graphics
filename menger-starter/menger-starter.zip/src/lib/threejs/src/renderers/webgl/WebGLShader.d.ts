export class WebGLShader {

	constructor( gl: WebGLRenderingContext, type: string, string: string );

}
