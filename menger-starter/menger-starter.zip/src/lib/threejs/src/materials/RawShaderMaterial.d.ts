import { ShaderMaterialParameters, ShaderMaterial } from './ShaderMaterial';

export class RawShaderMaterial extends ShaderMaterial {

	constructor( parameters?: ShaderMaterialParameters );

}
