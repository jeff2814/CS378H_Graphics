export function arrayMin( array: number[] ): number;
export function arrayMax( array: number[] ): number;
