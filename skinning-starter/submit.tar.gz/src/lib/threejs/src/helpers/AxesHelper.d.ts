import { LineSegments } from './../objects/LineSegments';

export class AxesHelper extends LineSegments {

	constructor( size?: number );

}
